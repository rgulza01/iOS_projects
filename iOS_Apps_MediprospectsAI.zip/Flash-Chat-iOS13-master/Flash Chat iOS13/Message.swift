import Foundation

struct Message {
    let sender: String //email
    let body: String
}
