import UIKit

class MessageCell: UITableViewCell {

    
    @IBOutlet weak var leftImagView: UIImageView!
    @IBOutlet weak var rightImageView: UIImageView!
    @IBOutlet weak var label: UILabel!
    @IBOutlet weak var messageBubble: UIView!
    //Nib is a old name for xip
    override func awakeFromNib() {
        super.awakeFromNib()
        // to change the form
        messageBubble.layer.cornerRadius = messageBubble.frame.size.height / 5
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
}
