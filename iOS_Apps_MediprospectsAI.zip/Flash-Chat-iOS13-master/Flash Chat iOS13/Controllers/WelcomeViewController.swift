import UIKit
import CLTypingLabel
class WelcomeViewController: UIViewController {

    //before:
    //@IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var titleLabel: CLTypingLabel!
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.isNavigationBarHidden = true
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        navigationController?.isNavigationBarHidden = false
    }
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        //before:
//        titleLabel.text = ""
//        var index = 0.0
//        let titleText = K.appName
//        for c in titleText
//        {
//            print("_______")
//            print(0.1 * index)
//            print(c)
//            Timer.scheduledTimer(withTimeInterval: 0.1 * index, repeats: false) { (timer) in
//                self.titleLabel.text?.append(c)
//            }
//            index += 1
//        }
       
        //for the new way for animation
        titleLabel.text = K.appName
        
    }
    

}
