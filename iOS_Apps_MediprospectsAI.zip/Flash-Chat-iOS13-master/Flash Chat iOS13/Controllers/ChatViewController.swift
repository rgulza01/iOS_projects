import UIKit
import Firebase
import Messages

class ChatViewController: UIViewController {

    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var messageTextfield: UITextField!
    
    //reference to database
    let db = Firestore.firestore()

    var messages: [Message] = []
   
    override func viewDidLoad()
    {
        //to use the extensions below
        tableView.dataSource = self
        //tableView.delegate = self --> not used anymore just as the exension related
        
        super.viewDidLoad()
        //to hide the back button, because that doens't make much sense anyways to be inside the chat
        navigationItem.hidesBackButton = true
        //additionally for a title inside the navigation bar
        title = K.appName
        
        //for custom design file, a custom xip, it needs to be registered in the viewDidLoad()
        tableView.register(UINib(nibName: K.cellNibName, bundle: nil), forCellReuseIdentifier: K.cellIdentifier)
        //to pull up data from the database
        loadMessages()
        
    }
    //to pull up data from the database
    //used to populate the tableview
    func loadMessages()
    {
         
        db.collection(K.FStore.collectionName)
            .order(by: K.FStore.dateField)
            .addSnapshotListener
            {(querySnapshot, error) in
            
            //messages array should be empty eveytime the methos runs
            self.messages = []
            
            
            if let e = error
            {
                print("There was an issue retrieving data from Firestore. \(e)")
            } else
            {
                if let snapshotDocuments = querySnapshot?.documents
                {
                    for doc in snapshotDocuments
                    {
                        let data = doc.data()
                        //conditional downcast to make it string
                        if let messageSender = data[K.FStore.senderField] as? String, let messageBody = data[K.FStore.bodyField] as? String
                        {
                            //now a message object using a message class can be created
                            let newMessage = Message(sender: messageSender, body: messageBody)
                            self.messages.append(newMessage)
                            
                            //we are trying to maniputale the user interface --> the table view
                            DispatchQueue.main.async
                            {
                                    self.tableView.reloadData()
                                
                                //the line I want to scroll to
                                let indexPath = IndexPath(row: self.messages.count - 1, section: 0)
                                //scroll to row
                                self.tableView.scrollToRow(at: indexPath, at: .top, animated: true)
                            }
                        }
                        
                    }
                }
            }
        }
    }
    //data sent to Firebase everytime the user presses it
    @IBAction func sendPressed(_ sender: UIButton)
    {
        if let messageBody = messageTextfield.text, let messageSender = Auth.auth().currentUser?.email
        {
            //if both not nil then send the data
            db.collection(K.FStore.collectionName).addDocument(data: [
                K.FStore.senderField: messageSender,
                K.FStore.bodyField: messageBody,
                K.FStore.dateField: Date().timeIntervalSince1970
            ]) { (error) in
                if let e = error
                {
                    print("There was an issue saving data to firestore, \(e)")
                } else
                {
                    print("Successfully saved data.")
                    
                    DispatchQueue.main.async
                        {
                        self.messageTextfield.text = ""
                        }

                }
            }
        }
        
    }
    
    //as it's a button and will perform an action
    @IBAction func logOutPressed(_ sender: UIBarButtonItem)
    {
        do
        {
          try Auth.auth().signOut()
            navigationController?.popToRootViewController(animated: true)
        } catch let signOutError as NSError
        {
          print ("Error signing out: %@", signOutError)
        }
          
    }
    
}
//when our table view loads up it will make a request for data
//UITableViewDataSource is the protocol that populates data --> how many cells and which cells to put in the tableView
//this is used by tableView.dataSource = self
extension ChatViewController: UITableViewDataSource
{
    //delegate method
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        //it will return the number dynamically now
        return messages.count
    }
    
    //UITableViewCell = a cell in each row to display
    //indexPath is the position
    //so I create a cell and return it to tableView
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        
        //to identify who is chatting
        let message = messages[indexPath.row]
        
        //the cell has been casted as a MessageCell class --> this  forms the connection between UI and code
        let cell = tableView.dequeueReusableCell(withIdentifier: K.cellIdentifier, for: indexPath) as! MessageCell
        //cell's text
        //before --> cell.textLabel?.text = messages[indexPath.row].body
        //after the cast
        cell.label.text = message.body
        
        //if it's from the current user
        if message.sender == Auth.auth().currentUser?.email
        {
            cell.leftImagView.isHidden = true
            cell.rightImageView.isHidden = false
            cell.messageBubble.backgroundColor = UIColor(named: K.BrandColors.purple)
            cell.label.textColor = UIColor(named: K.BrandColors.lightPurple)
        } else
        {
            cell.leftImagView.isHidden = false
            cell.rightImageView.isHidden = true
            cell.messageBubble.backgroundColor = UIColor(named: K.BrandColors.lightPurple)
            cell.label.textColor = UIColor(named: K.BrandColors.purple)
        }
        
        
        //this returns it in the tableView
        return cell
    }
}

//whenever the table view is interacted by the user
//extension ChatViewController: UITableViewDelegate
//{
//    //e.g. whenever a row in the tableView is selected
//    //trigger this method (not needed for our app now)
//    func tableView(_ tableView: UITableView, didSelectRowAt: IndexPath, forRowAt indexPath: IndexPath) {
//        print(indexPath.row)
//    }
//}
