import UIKit
import Firebase

class RegisterViewController: UIViewController {

    @IBOutlet weak var emailTextfield: UITextField!
    @IBOutlet weak var passwordTextfield: UITextField!
    
    @IBAction func registerPressed(_ sender: UIButton) {
        //if email textfield is not nil + it can be turned into a string,
        //--> store it in the property called email
        //only if both of these don't fail then...{}
        if let email = emailTextfield.text, let password = passwordTextfield.text
        {
            //now the email and password inside are string (check with alt clicking)
            Auth.auth().createUser(withEmail: email, password: password)
            { authResult, error in
              // this is the inside of a closure becuase it has "in"
              // we get access to two things
                //authResult is the user's account data after they have been succesfully registered
                //the error is an optional as well
                //to turn it into a non-optional
                if let e = error
                {
                    print(e)
                    //it can be made into pop up as well but this is for me, the developer's use for now
                    //e.localizedDescription gives desciption of the problem in the language of where the user is but in my case it was alredy like that. This is more useful when this is saved in a variable and given as a popup on the screen
                } else
                {
                    //is no errors --> navigate to chat view controller
                    //segue had been already set up and has an identifier "RegisterToChat"
                    //the sender is self becasue this is the origin of that segue, this register view controller
                    //if you are inside a closure you have to put self.methodName before any method
                    self.performSegue(withIdentifier: K.registerSegue, sender: self)
                }
            }
            
        }
        
    }
    
}
